# Overview

This is a React + TypeScript web application that serves as an AI-powered personal assistant for budgeting and vehicle search. The application uses OpenAI's GPT-5 model to provide intelligent financial analysis and vehicle recommendations through a clean, modern user interface. Built with Vite for fast development and optimized builds, it features a tab-based navigation system allowing users to switch between budget analysis and vehicle search functionalities.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React 18** with TypeScript for type-safe component development
- **Vite** as the build tool and development server for fast hot module reloading
- **CSS-in-JS** approach with component-specific styling using CSS modules
- **Tab-based navigation** allowing users to switch between different AI assistant features
- **Component-based architecture** with separate components for budgeting (`BudgetingAI`) and vehicle search (`VehicleSearchAI`)

## Backend Architecture
- **Express.js** server running on port 3001 for API endpoints
- **RESTful API design** with dedicated endpoints for budget analysis and vehicle search
- **CORS enabled** for cross-origin requests between frontend and backend
- **JSON-based** request/response format for all API interactions
- **Environment variable configuration** for sensitive API keys

## AI Integration
- **OpenAI GPT-5** integration for natural language processing and analysis
- **Structured JSON responses** enforced through OpenAI's response formatting
- **Budget analysis** that categorizes expenses and provides personalized recommendations
- **Vehicle search** that matches user preferences with suitable vehicle recommendations
- **Error handling** with graceful fallbacks for API failures

## Security & Configuration
- **API key protection** by keeping OpenAI credentials on the server side only
- **Environment-based configuration** for development vs production environments
- **Type safety** throughout the application with TypeScript interfaces
- **Input validation** on both client and server sides

# External Dependencies

## AI Services
- **OpenAI API** (GPT-5) - Primary AI engine for budget analysis and vehicle recommendations
- Requires `OPENAI_API_KEY` environment variable for authentication

## Development Tools
- **Vite** - Frontend build tool and development server
- **TypeScript** - Type checking and enhanced developer experience
- **React DevTools** compatible for debugging

## Runtime Dependencies
- **Express.js** - Backend web framework
- **CORS** - Cross-origin resource sharing middleware
- **React** - Frontend UI library
- **React DOM** - React rendering for web browsers

## Build & Deployment
- **Replit** hosting platform with automatic deployment
- **Node.js** runtime environment
- **npm/package.json** for dependency management
- Configured for both development (`npm run dev`) and production builds (`npm run build`)